(function ($) {
    $.fn.serializeFormJSON = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
})(jQuery);
/**
 * Toggle text
 */
jQuery.fn.extend({
    toggleText: function (a, b) {
        var isClicked = false;
        var that = this;
        this.click(function () {
            if (isClicked) {
                that.text(a);
                isClicked = false;
            }
            else {
                that.text(b);
                isClicked = true;
            }
        });
        return this;
    }
});

/**
 * Home page categories
 * @param ref
 */
function cc_show_child(ref) {
    jQuery("#sub_child" + ref.id).slideToggle();
    jQuery(ref).toggleClass('cat-minus');//find('.cat-sign').toggleText("+", "-");
}
jQuery(document).ready(function ($) {
    /**
     * Home page tab switcher
     */
    $("a.switcher").bind("click", function (e) {
        e.preventDefault();

        var theid = $(this).attr("id");
        var theproducts = $("ul#products");
        var classNames = $(this).attr('class').split(' ');
        var postmeta = $(".post_meta");
        var text = $(".contents p");
        var gridthumb = "images/products/grid-default-thumb.png";
        var listthumb = "images/products/list-default-thumb.png";

        if ($(this).hasClass("active")) {
            // if currently clicked button has the active class
            // then we do nothing!
            return false;
        } else {
            // otherwise we are clicking on the inactive button
            // and in the process of switching views!

            if (theid == "gridview") {
                $(this).addClass("active");
                $("#listview").removeClass("active");

                $("#listview").children("img").attr("src", "images/list-view.png");

                var theimg = $(this).children("img");
                theimg.attr("src", "images/grid-view-active.png");

                // remove the list class and change to grid
                theproducts.removeClass("list");
                theproducts.addClass("grid");
                postmeta.hide();
                text.hide();
                // update all thumbnails to larger size
                //$("img.thumb").attr("src",gridthumb);
            }

            else if (theid == "listview") {
                $(this).addClass("active");
                $("#gridview").removeClass("active");

                $("#gridview").children("img").attr("src", "images/grid-view.png");

                var theimg = $(this).children("img");
                theimg.attr("src", "images/list-view-active.png");
                postmeta.show();
                text.show();
                // remove the grid view and change to list
                theproducts.removeClass("grid")
                theproducts.addClass("list");
                // update all thumbnails to smaller size
                //$("img.thumb").attr("src",listthumb);
            }
        }

    });
});