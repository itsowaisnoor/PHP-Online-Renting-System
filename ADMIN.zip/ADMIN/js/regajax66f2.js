/**
 * Registration ajax
 * @type type
 */
jQuery(document).ready(function () {
    jQuery('#register .submit').click(function (e) {
        e.preventDefault();
        var data = {
            action: 'cc_registration',
            user_name: jQuery('#userid').val(),
            user_email: jQuery('#email').val(),
            user_password1: jQuery('#password1').val(),
            user_password2: jQuery('#password2').val(),
            recaptcha_response_field: jQuery('#recaptcha_response_field').val(),
            recaptcha_challenge_field: jQuery('#recaptcha_challenge_field').val(),
            request_url: cc_ajax.request_url,
            terms: jQuery('#terms').val(),
            nonce: cc_ajax.nonce
        };
        if (jQuery('#terms').is(':checked')) {
            data.terms = 'on';
        }
        jQuery.post(cc_ajax.url, data, function (response) {
            if (response) {
                var obj = jQuery.parseJSON(response);
                jQuery('.reg_error').empty();
                jQuery('.reg_error').append(obj.errors);
                if (obj.success) {
                    window.location = obj.success;
                }
                jQuery("html, body").animate({scrollTop: 0}, "slow");
            }
        });
    });
});