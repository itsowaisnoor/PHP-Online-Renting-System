<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		include('../../config.tpl');
		include('../../db/connect.php');
		include('../controller/dashboardController.tpl');
			
			$message="";
			$dashboard_Control = new dashboardController();
				
			if($dashboard_Control->updateNow())
				echo $message = "Updated";
			else
				echo $message="*Something went wrong";
	}

	else
	 header('Location:'.WEBPATH.'ERROR404');


?>