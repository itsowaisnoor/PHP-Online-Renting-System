<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		include('../../config.tpl');
		include('../../db/connect.php');
		include('../controller/dashboardController.tpl');
			$id = $_POST['id'];
			
			$dashboard_Control = new dashboardController();
			if($result=$dashboard_Control->getDetails($id))
		    {
				$dataArray=null;
				while($row=mysqli_fetch_assoc($result))
				{
					$dataArray=array(
					     'COMPANYNAME'=>$row['companyname'],
						 'EMAIL'=>$row['email'],
						 'CONTACT'=>$row['phone_no'],
						 'STATEID'=>$row['state_id'],
						 'CITYID'=>$row['city_id'],
						 'CITYNAME'=>$row['city']
					);
				}
				echo json_encode($dataArray);
			}
			else
				echo "Something went wrong";
	}

	else
	 header('Location:'.WEBPATH.'ERROR404');


?>