<?php
	
if($_SERVER['REQUEST_METHOD'] == "POST")
{
	 $id = $_POST['ID'];
	 $productname = $_POST['PRODUCTNAME'];
	 $username = $_POST['USERNAME'];
	 $contact = $_POST['CONTACT'];
	 
	 $to = "owaisnoor0@gmail.com";
	 
$body  =  "USERNAME: $username CONTACT NUMBER $contact WANTS TO MAKE HIS/HER ADD PREMIUM. ADD ID [$id] PRODUCTNAME [$productname]";
$subject = "Request For a PREMIUM ADD";
$headers = 'From: ' . $to;
mail($to, $subject, $body, $headers) or die ("OOPS SOMETHING WENT WRONG..TRY AGAIN!");
	echo $message = "Your Request for Premium Add has been sent...We Will Notify You Shortly";
			
	 
	
		
		
		
}

	else
	 header('Location:'.WEBPATH.'ERROR404');

?>