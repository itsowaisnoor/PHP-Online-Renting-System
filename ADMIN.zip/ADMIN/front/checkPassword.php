<?php
   
      

		$password = $_REQUEST['pwd'];
		include('../../config.tpl');
		include('../../db/connect.php');
		include('../controller/dashboardController.tpl');
		
		$dashboard_Control = new dashboardController();
		$result = $dashboard_Control->getPassword($password);
		if($result)
		{
			echo 'true';
		}
		else
			echo 'false';
		

 

?>