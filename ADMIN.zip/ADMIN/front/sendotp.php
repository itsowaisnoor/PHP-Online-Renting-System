<?php
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
			include('../../config.tpl');
		include('../../db/connect.php');
		include('../model/smsModel.tpl');
		include('../controller/postController.tpl');
		
			 $sms = new smsModel();
              $post=new postController();
              $sms->setUsername();
              $sms->setSenderID();
              $sms->setPassword();
              $sms->setPhone($post->getPhoneNo());
			  
			  if($post->sendOTP($sms))
			  		echo 'OTP Sent Successfully';
			  else
			  		echo 'Try again';
	}
?>