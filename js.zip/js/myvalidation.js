//User validation 

		
		function testLogin()
		{
             $("#loginform1").validate({
                 
          rules:
              {
                log: 
                {
                    required: true,
                },
                pwd: 
                { 
                    required:true,
                },
              },
           messages:
               {
                log:
				{
                    required:"*Username is required",
                },
                pwd:
				{
                    required: "*Password is required",
                },    
			},

           }); 
		}
          
            
// regsiter form validation
function registerUser()
{
	 $.validator.addMethod("ValueSelect",function(value,element,arg){
			return value!=arg;},"*Please Select a State"
		);
		
	 $.validator.addMethod("con_no", function(value, element) {
            return this.optional(element) || value == value.match(/^[0-9]{2,20}$/);
         });
		 
	 $.validator.addMethod("compName", function(value, element) {
            return this.optional(element) || value == value.match(/^[a-zA-Z 0-9_-]{2,}$/);
         });
		 
		  $.validator.addMethod("user", function(value, element) {
            return this.optional(element) || value == value.match(/^[a-zA-Z 0-9_-]{2,}$/);
         });
		
	$("#registerform").validate({
                 
          rules:	
              {
                companyName: 
                {
                    required: true,
					compName:true,
                },
                username: 
                { 
                    required:true,
					user:true,
                },
				email: 
                { 
                    required:true,
					email:true,
					remote:'front/checkEmailExist.php'
                },
				password: 
                { 
                    required:true,
                },
				cPassword: 
                { 
                    required:true,
					equalTo: '#pwd',
                },
				
				
				phone_no: 
                { 
                    required:true,
					con_no:true
					
                },
				stateName:
				{
					ValueSelect:"0",	
				},
				city:
				{
					ValueSelect:"0",	
				},
			
              },
           messages:
               {
                companyName:
				{
                    required:"*Company Name is required",
					compName:"Invalid Input",
                },
                username:
				{
                    required: "*Username is required",
					user:"Invalid Username",
                }, 
				 email:
				{
                    required: "*Email is required",
					email:"*Invalid email format",
					remote:"*Email already exists"
                }, 
				 password:
				{
                    required: "*Password is required",
                },
				 cPassword:
				{
                    required: "*Confirm Password is required",
					equalTo:"*Passwords doesn't match",
                },
				 
				 phone_no:
				{
                    required: "*Phone Number is required",
					con_no:"*Invalid phone number"
                }, 
				city:
				{
					ValueSelect:"Please select a city",
				},
						
				
			  
			},

           }); 
}