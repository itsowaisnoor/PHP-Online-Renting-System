<html>
	<head>
		<script type="text/javascript" src="js/jquery.min.js"></script>
        <script src="https://apis.mapmyindia.com/advancedmaps/v1/52eb3an841rimel8o3gt1ls7a76wf8dv/map_load?v=0.1"></script>
        
        <script type="text/javascript">
		var lng,lat;
		getLocation();
		function getLocation() {
				if (navigator.geolocation) {
					navigator.geolocation.watchPosition(showPosition);
				} else {
					x.innerHTML = "Geolocation is not supported by this browser.";
				}
			}
			function showPosition(position) {
				lng = position.coords.longitude;
                lat = position.coords.latitude;
				var rev_geocode_api_url="http://apis.mapmyindia.com/advancedmaps/v1/hw1b61k16hd8fma3abi96msmudfznw24/rev_geocode?";
			 var rev_geocode_api_url_with_param = rev_geocode_api_url+"lng=" + lng + "&lat=" + lat;
			 getUrlResult(rev_geocode_api_url_with_param);
			}
			
			
			 function getUrlResult(api_url) {
                    
                    $.ajax({
                        type: "POST",
                        dataType: 'text',
                        url: "getResponse.php",
                        async: false,
                        data: {
                            url: JSON.stringify(api_url),
                        },
                        success: function (result) {
                            var jsondata = JSON.parse(result);
                            if (jsondata.responseCode == 200) {
                                   alert();
                                    
                            }
                            /*handle the error codes and put the responses in divs. more error codes can be viewed in the documentation*/
                            else{
                               document.getElementById('result').innerHTML="No Result found" ;
                            }
                        }
                    });
                }

        </script>
    </head>
    <body>
    
    </body>
</html>