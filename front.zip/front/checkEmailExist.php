<?php
   
      

		$email=$_REQUEST['email'];
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/registerController.tpl');
		
		$registerControl = new registerController();
		$result = $registerControl->getEmail($email);
		if($result)
		{
			echo 'false';
		}
		else
			echo 'true';
		

 

?>