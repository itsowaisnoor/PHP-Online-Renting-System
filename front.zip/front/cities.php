<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$stateID=$_POST['STATEID'];
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/registerController.tpl');
		
		$register_control=new registerController();
		$result=$register_control->getCities($stateID);
		if($result)
		{
			$option="<option value='0'>--Select City--</option>";
			while($row=mysqli_fetch_assoc($result))
			{
				$option.="<option value='".$row['id']."'>".$row['name']."</option>";
			}
			echo $option;
		}
		else
			echo "FAIL";
		
	}

?>