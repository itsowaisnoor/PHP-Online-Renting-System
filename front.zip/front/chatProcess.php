<?php

		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/messageController.tpl');
			
  	class processChat extends messageController{
		private $connect;
        
       function __construct()
       {
       		 $this->connect=dbConnect::connect();
       }       
       
	 public function getChat($RID,$SID,$PRODUCTID){
				
	$SQL = "SELECT * FROM `messages` WHERE `sender`= '".$SID."'AND `reciever` = '".$RID."' AND `productid`='".$PRODUCTID."' OR `sender`= '".$RID."'AND `reciever` = '".$SID."' AND `productid`='".$PRODUCTID."';";
					  
        if($ress = $this->connect->query($SQL)){
            if(mysqli_num_rows($ress) !=0){
                while($row = mysqli_fetch_assoc($ress)){
              echo "<small style='font-size:16px;'><strong>". $this->fetchUserName($row['sender'])." says : </strong>".$row['message']. "</small><br/>";
                }
            
          }
					  						
			}
					  						
			}  
			
	 public function fetchUserName($id){
		  $sql = "SELECT `username` FROM `users` WHERE `id`='".$id."'";	
			$result = $this->connect->query($sql);
			$row = mysqli_fetch_assoc($result);
			return $row['username'];		
		}
	
	
	public function sendChat($sender,$reciever,$productid,$message){
	$SQL = "INSERT INTO `messages` VALUES (NULL,'".$sender."','".$reciever."','".$productid."',
'".$message."','".date('Y-m-d H:i:s')."');";
				 if($ress = $this->connect->query($SQL))
				 echo "<small style='font-size:16px;'><strong>".$this->fetchUserName($sender). " says : </strong>".$message.
				 "</small><br/>";
				 else
				 echo "Could not send message...Try again later!";
				
			}
	
			  	  
	}



$processChat = new processChat();
		if($_SERVER["REQUEST_METHOD"]=="POST"){
				if(isset($_POST['SENDER'],$_POST['RECIEVER'],$_POST['PRODUCTID'],$_POST['MESSAGE']))
				$processChat->sendChat($_POST['SENDER'],$_POST['RECIEVER'],$_POST['PRODUCTID'],$_POST['MESSAGE']);
			
		}
		else{
			
			$processChat->getChat($_GET['SID'],$_GET['RID'],$_GET['PRODUCTID']);
		}




















?>