<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/messageController.tpl');
		$message="";
			$sender = $_POST['SENDERID'];
			$reciever = $_POST['RECIEVERID'];
			$productid = $_POST['PRODUCTID'];
			$message = $_POST['MESSAGE'];
			
			$messageControl = new messageController();
			if($messageControl->sendMessage($sender,$reciever,$productid,$message))
				echo $message = "Message Sent Successfully!";
			else
				echo $message="Invalid Message String Format";
		
		
}

else
{
	 header('Location:'.WEBPATH.'ERROR404');
	 
}
?>