<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		
		include('../config.tpl');
		include('../db/connect.php');
		include('../ADMIN/controller/postController.tpl');
		$post=new postController();
		
		if($result = $post->getProductName($_POST['PRODUCTID']))
		{
			$row=mysqli_fetch_assoc($result);
			echo $row['productname'];
		}
		else
			echo 'error';
	
	}
	else
	 header('Location:'.WEBPATH.'ERROR404');


?>