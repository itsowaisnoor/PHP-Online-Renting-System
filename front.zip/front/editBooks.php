<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/adminBooksController.tpl');
		
		$message="";
			$adminBooksControl = new adminBooksController();
			if($adminBooksControl->updateBooksNow())
				echo $message = "Books Updated Successfully";
			else
				echo $message="Something Went Wrong While Updating the Books";
		
	
	}
	else
	 header('Location:'.WEBPATH.'ERROR404');



?>