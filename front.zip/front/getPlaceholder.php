<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/categoryController.tpl');
		$control=new categoryController();
		
		if($placeholder=$control->getPlaceHolder($_POST['ID']))
		{
			echo $placeholder;	
		}
	
	}
	else
	 header('Location:'.WEBPATH.'ERROR404');


?>