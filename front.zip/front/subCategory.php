<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$CATEGORYID = $_POST['CATEGORYID'];
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/subCategoryController.tpl');
		
		$subCategoryControl = new subCategoryController();
		$result = $subCategoryControl->getAllSubCategories($CATEGORYID);
		if($result)
		{
		    if(mysqli_num_rows($result)>0)
			{
				$option="<option value='0'>--Select one--</option>";
				while($row=mysqli_fetch_assoc($result))
				{
					$option.="<option value='".$row['id']."'>".$row['name']."</option>";
				}
				echo $option;
			}
			else
				echo "FAIL";
		}
		else
			echo "FAIL";
		
	}

?>