<?php

if($_SERVER['REQUEST_METHOD'] == "POST")
{
		
		include('../config.tpl');
		include('../db/connect.php');
		include('../controller/adminBooksController.tpl');
			
		$message="";
		if(is_numeric($_POST['ID']))
		{
			$adminBooksControl = new adminBooksController();
			if($adminBooksControl->deleteBooks($_POST['ID']))
				echo $message = "SUCCESS";
			else
				echo $message="*Something went wrong";
		}
		else
			echo $message="Some unknown error occured";
		
	
	}
	else
	 header('Location:'.WEBPATH.'ERROR404');


?>