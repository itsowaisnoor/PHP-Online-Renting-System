<?php

		require_once('../config.tpl');
		require_once('../db/connect.php');
		require_once('../controller/searchController.tpl');
		require_once('../inc/weos_date.tpl');		
		$keywords = BUNDLE::filerInput($_POST['KEYWORDS']);
		
		$category = isset($_POST['cat'])?$_POST['cat']:"";
		$location = isset($_POST['LOC'])?$_POST['LOC']:"";
		
		
		$get = new get($keywords,$category,$location);
		
?>
		
			<div style="width:100%; min-height:10px;
            font-family:Arial;font-size:15px">
            <div style="height:40px; width:100%; color:red; line-height:20px;">
            		<?php
				
	if(strlen($word = $_POST['KEYWORDS']) >= 0){
					$count = $get->TotalRows;
					$suffix = ($count !=1) ? 's' : '';
					
					if($count != 0){
						$ress= "Your Search returned  ". $count . 
						"   result". $suffix; 
					}else{
						$ress= "Your Search returned  0 " . 
						"   result". $suffix;
					}
						echo $ress.'  <small style="color:green"
						>('.round($get->timer,4) . ' seconds)  </small>';
					?>
            </div>
            <?php
			if($count!=0){	
				foreach($get->results as $res){
			?>
           <div id="content">                                                                       
            <div id="recent" style="display: block;">                                            
                <ul id="products" class="list clearfix">
                	 <li class="thumbnail">
                      <section class="thumbs">
     <a href="Items?item=<?php echo $res['ID']; ?>">
     <img src="<?php echo $res['IMAGE']; ?>" class="postimg " alt="Post Image"></a> 
                            <section class="thumb_item">
                                 <span class="price"> Rs.<?php echo $res['RATE']; ?> 
  <label style="font-size:14px;" title="Rs. <?php echo $res['RATE']; ?> <?php echo $res['RENTTIME'];?>"><?php echo $res['RENTTIME'];?></label>
           </span>
                                 <a class="view" href="Items?item=<?php echo $res['ID']; ?>">View it!</a>
                            </section>
						</section>
                        <section class="contents">
                            <h6 class="title">
                            <a href="Items?item=<?php echo $res['ID']; ?>" rel="bookmark">
                            <?php echo $res['PRODUCTNAME']."..."; ?>
                            </a></h6>
                            <p><?php echo $res['DESCP']."..."; ?> </p>
                            <div class="clear" style="display: none;"></div>
                              <ul class="post_meta">
                                  <li class="estimate">
                                  	 <?php
                                    echo "<small>".nicetime($res['TIME'])."</small>";
                                     ?>
                                  </li>
                                  <li class="cate">
                                 	<a href="Items?item=<?php echo $res['ID']; ?>" rel="tag"><?php echo $res['TAGS']."..."; ?></a>
                                  </li>
                                  <li class="author">by&nbsp;<a href="Items?item=<?php echo $res['ID']; ?>" rel="author">
                                  <?php echo $get->fetchUserName($res['USERID']);?> </a>
                                  </li>
                              </ul>
                          </section>
                      </li>
                  </ul>
                </div>
              </div>                        
            <?php
				}
				}
			?>
			</div>
<?php		
	}
	else
	{
		echo '<h1 style="text-align:center;">Invalid Input...No Results Found</h1>';	
	}
		
?>